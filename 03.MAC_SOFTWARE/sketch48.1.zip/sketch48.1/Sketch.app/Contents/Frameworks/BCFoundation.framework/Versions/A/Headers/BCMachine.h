//  Created by Sam Deane on 15/10/2015.
//  Copyright (c) 2015 Bohemian Coding. All rights reserved.

extern NSData *BCGetMacAddress(void);