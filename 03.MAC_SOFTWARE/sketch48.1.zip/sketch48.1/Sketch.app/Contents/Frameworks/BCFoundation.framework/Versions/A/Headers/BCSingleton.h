//  Created by Pieter Omvlee on 8/16/08.
//  Copyright 2008 Bohemian Coding. All rights reserved.

@interface BCSingleton : NSObject
+ (instancetype)sharedInstance;
@end
